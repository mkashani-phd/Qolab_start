import typer
import toml
import os
from typing_extensions import Annotated
import iqcc_cloud_client
from pathlib import Path
import jwt
from rich.console import Console

app = typer.Typer()
console = Console()


@app.command()
def setup(
    IQCC_API_token: Annotated[
        str, typer.Option(prompt="Paste your IQCC API token and press enter")
    ],
):
    """Sets up a token for usage of the IQCC for current user

    Args:
        token (str): API token provided by the IQCC
    """
    Path(os.path.join(os.path.expanduser("~"), ".config", "iqcc_cloud")).mkdir(
        parents=True, exist_ok=True
    )
    with open(
        os.path.join(
            os.path.expanduser("~"), ".config", "iqcc_cloud", "config.toml"
        ),
        "w",
    ) as f:
        data = {"api_token": IQCC_API_token}
        try:
            decoded_data = jwt.decode(
                IQCC_API_token, options={"verify_signature": False}
            )
            console.print(
                f":thumbs_up: Token for user [bold blue]{decoded_data['user_id']}[/bold blue] provided"
            )

        except Exception as _:
            console.print("[bold red]:red_circle: Invalid JWT token passed")
            exit()
        toml.dump(data, f)

    console.print(
        "[bold green]:white_check_mark: Your access token is setup successfully.[/bold green]\n:rocket: Now you can use IQCC client without explicitly specifying the token."
    )


@app.command()
def version():
    """Prints version information"""
    print(f"iqcc-cloud-client version {iqcc_cloud_client.__version__}")


if __name__ == "__main__":
    app()
