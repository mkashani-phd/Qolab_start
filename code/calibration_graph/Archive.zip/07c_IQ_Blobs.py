"""
        IQ BLOBS
This sequence involves measuring the state of the resonator 'N' times, first after thermalization (with the qubit
in the |g> state) and then after applying a pi pulse to the qubit (bringing the qubit to the |e> state) successively.
The resulting IQ blobs are displayed, and the data is processed to determine:
    - The rotation angle required for the integration weights, ensuring that the separation between |g> and |e> states
      aligns with the 'I' quadrature.
    - The threshold along the 'I' quadrature for effective qubit state discrimination.
    - The readout fidelity matrix, which is also influenced by the pi pulse fidelity.

Prerequisites:
    - Having found the resonance frequency of the resonator coupled to the qubit under study (resonator_spectroscopy).
    - Having calibrated qubit pi pulse (x180) by running qubit.wait(qubit.thermalization_time * u.ns) spectroscopy, power_rabi and updated the state.
    - Set the desired flux bias

Next steps before going to the next node:
    - Update the rotation angle (rotation_angle) in the state.
    - Update the g -> e thresholds (threshold & rus_threshold) in the state.
    - Update the confusion matrices in the state.
    - Save the current state
"""
# %%
from typing import List, Literal, Optional

import matplotlib.pyplot as plt
import numpy as np
import xarray as xr
from qm import SimulationConfig
from qm.qua import *
from qualang_tools.analysis.discriminator import two_state_discriminator
from qualang_tools.multi_user import qm_session
from qualang_tools.results import fetching_tool, progress_counter
from qualang_tools.units import unit

# %% {Imports}
from qualibrate import NodeParameters, QualibrationNode
from quam_libs.components import QuAM
from quam_libs.lib.plot_utils import QubitGrid, grid_iter
from quam_libs.lib.qua_datasets import convert_IQ_to_V
from quam_libs.lib.save_utils import fetch_results_as_xarray, load_dataset
from quam_libs.macros import active_reset, qua_declaration


# %% {Node_parameters}
class Parameters(NodeParameters):

    qubits: Optional[List[str]] = None
    num_runs: int = 2000
    reset_type_thermal_or_active: Literal["thermal", "active"] = "thermal"
    flux_point_joint_or_independent: Literal["joint", "independent"] = "independent"
    operation_name: str = "readout"  # or "readout_QND"
    simulate: bool = False
    simulation_duration_ns: int = 2500
    timeout: int = 100
    load_data_id: Optional[int] = None
    multiplexed: bool = False

description = """Typical Runtime w/Default Params:
30-35s for all qubits
8-10s per qubit
"""

node = QualibrationNode(name="07b_IQ_Blobs", description=description, parameters=Parameters())


# %% {Initialize_QuAM_and_QOP}
# Class containing tools to help handling units and conversions.
u = unit(coerce_to_integer=True)
# Instantiate the QuAM class from the state file
machine = QuAM.load()
# Generate the OPX and Octave configurations
config = machine.generate_config()
# Open Communication with the QOP
if node.parameters.load_data_id is None:
    qmm = machine.connect()

# Get the relevant QuAM components
if node.parameters.qubits is None or node.parameters.qubits == "":
    qubits = machine.active_qubits
else:
    qubits = [machine.qubits[q] for q in node.parameters.qubits]
num_qubits = len(qubits)


# %% {QUA_program}
n_runs = node.parameters.num_runs  # Number of runs
flux_point = node.parameters.flux_point_joint_or_independent  # 'independent' or 'joint'
reset_type = node.parameters.reset_type_thermal_or_active  # "active" or "thermal"
operation_name = node.parameters.operation_name
with program() as iq_blobs:
    I_g, I_g_st, Q_g, Q_g_st, n, n_st = qua_declaration(num_qubits=num_qubits)
    I_e, I_e_st, Q_e, Q_e_st, _, _ = qua_declaration(num_qubits=num_qubits)
    I_f, I_f_st, Q_f, Q_f_st, _, _ = qua_declaration(num_qubits=num_qubits)

    shot = [declare(int) for _ in range(num_qubits)]

    if node.parameters.multiplexed:
        for i , qubit in enumerate(qubits):
            machine.set_all_fluxes(flux_point=flux_point, target=qubit)

    for i, qubit in enumerate(qubits):

        if not node.parameters.multiplexed:
            # Bring the active qubits to the desired frequency point
            machine.set_all_fluxes(flux_point=flux_point, target=qubit)

        with for_(shot[i], 0, shot[i] < n_runs, shot[i] + 1):
            save(shot[i], n_st)
            # ground iq blobs for all qubits
            
            if reset_type == "active":
                active_reset(qubit, "readout")
            elif reset_type == "thermal":
                qubit.wait(qubit.thermalization_time * u.ns)
            else:
                raise ValueError(f"Unrecognized reset type {reset_type}.")

            qubit.align()
            qubit.resonator.measure(operation_name, qua_vars=(I_g[i], Q_g[i]))
            qubit.resonator.wait(qubit.resonator.depletion_time * u.ns)
            # save data
            save(I_g[i], I_g_st[i])
            save(Q_g[i], Q_g_st[i])

            qubit.align()
            # excited iq blobs for all qubits
            if reset_type == "active":
                active_reset(qubit, "readout")
            elif reset_type == "thermal":
                qubit.wait(machine.thermalization_time * u.ns)
            else:
                raise ValueError(f"Unrecognized reset type {reset_type}.")
            qubit.align()
            qubit.xy.play("x180")
            qubit.align()
            qubit.resonator.measure(operation_name, qua_vars=(I_e[i], Q_e[i]))
            qubit.resonator.wait(qubit.resonator.depletion_time * u.ns)
            # save data
            save(I_e[i], I_e_st[i])
            save(Q_e[i], Q_e_st[i])

            qubit.align()

            # Reset to |0>
            if reset_type == "active":
                active_reset(qubit, "readout")
            elif reset_type == "thermal":
                qubit.wait(machine.thermalization_time * u.ns)
            else:
                raise ValueError(f"Unrecognized reset type {reset_type}.")


            # Prepare |1>
            # qubit.xy.play("x180")
            # qubit.align()


            # === IMPORTANT ===
            # Move the XY drive DOWN by anharmonicity to hit the 1↔2 transition.
            # (Use minus because transmon’s anharmonicity is negative)
            qubit.xy.update_frequency(qubit.xy.intermediate_frequency - qubit.anharmonicity)


            # Drive |1> → |2>
            qubit.xy.play("EF_x180")   # your EF calibrated pi pulse



            # Measure |2>
            qubit.resonator.measure("readout", qua_vars=(I_f[i], Q_f[i]))

            qubit.resonator.wait(qubit.resonator.depletion_time * u.ns)

            qubit.align()


            # Return the XY freq to its normal value for future gates
            qubit.xy.update_frequency(qubit.xy.intermediate_frequency)
            qubit.align()

            # Save data
            save(I_f[i], I_f_st[i])
            save(Q_f[i], Q_f_st[i])


        # Measure sequentially
        if not node.parameters.multiplexed:
            align()

    with stream_processing():
        n_st.save("n")
        for i in range(num_qubits):
            I_g_st[i].save_all(f"I_g{i + 1}")
            Q_g_st[i].save_all(f"Q_g{i + 1}")
            I_e_st[i].save_all(f"I_e{i + 1}")
            Q_e_st[i].save_all(f"Q_e{i + 1}")
            I_f_st[i].save_all(f"I_f{i + 1}")
            Q_f_st[i].save_all(f"Q_f{i + 1}")


# %% {Simulate_or_execute}
if node.parameters.simulate:
    # Simulates the QUA program for the specified duration
    simulation_config = SimulationConfig(duration=node.parameters.simulation_duration_ns * 4)  # In clock cycles = 4ns
    job = qmm.simulate(config, iq_blobs, simulation_config)
    # Get the simulated samples and plot them for all controllers
    samples = job.get_simulated_samples()
    fig, ax = plt.subplots(nrows=len(samples.keys()), sharex=True)
    for i, con in enumerate(samples.keys()):
        plt.subplot(len(samples.keys()), 1, i + 1)
        samples[con].plot()
        plt.title(con)
    plt.tight_layout()
    # Save the figure
    node.results = {"figure": plt.gcf()}
    node.machine = machine
    node.save()

elif node.parameters.load_data_id is None:
    with qm_session(qmm, config, timeout=node.parameters.timeout) as qm:
        job = qm.execute(iq_blobs)
        for i in range(num_qubits):
            results = fetching_tool(job, ["n"], mode="live")
            while results.is_processing():
                n = results.fetch_all()[0]
                progress_counter(n, n_runs, start_time=results.start_time)

# %% {Data_fetching_and_dataset_creation}
if not node.parameters.simulate:
    if node.parameters.load_data_id is None:
        # Fetch the data from the OPX and convert it into a xarray with corresponding axes (from most inner to outer loop)
        ds = fetch_results_as_xarray(job.result_handles, qubits, {"N": np.linspace(1, n_runs, n_runs)})

        # Fix the structure of ds to avoid tuples
        def extract_value(element):
            if isinstance(element, tuple):
                return element[0]
            return element

        ds = xr.apply_ufunc(
            extract_value,
            ds,
            vectorize=True,  # This ensures the function is applied element-wise
            dask="parallelized",  # This allows for parallel processing
            output_dtypes=[float],  # Specify the output data type
        )
        # Convert IQ data into volts
        ds = convert_IQ_to_V(ds, qubits, ["I_g", "Q_g", "I_e", "Q_e"])
    else:
        node = node.load_from_id(node.parameters.load_data_id)
        ds = node.results["ds"]

    # %% {Data_analysis}
    node.results = {"ds": ds, "figs": {}, "results": {}}
    plot_individual = False
    for q in qubits:
        # Perform two state discrimination
        angle, threshold, fidelity, gg, ge, eg, ee = two_state_discriminator(
            ds.I_g.sel(qubit=q.name),
            ds.Q_g.sel(qubit=q.name),
            ds.I_e.sel(qubit=q.name),
            ds.Q_e.sel(qubit=q.name),
            
            True,
            b_plot=plot_individual,
        )
        # TODO: check the difference between the above and the below
        # Get the rotated 'I' quadrature
        I_rot = ds.I_g.sel(qubit=q.name) * np.cos(angle) - ds.Q_g.sel(qubit=q.name) * np.sin(angle)
        # Get the blobs histogram along the rotated axis
        hist = np.histogram(I_rot, bins=100)
        # Get the discriminating threshold along the rotated axis
        RUS_threshold = hist[1][1:][np.argmax(hist[0])]
        # Save the individual figures if requested
        if plot_individual:
            fig = plt.gcf()
            plt.show()
            node.results["figs"][q.name] = fig
        node.results["results"][q.name] = {}
        node.results["results"][q.name]["angle"] = float(angle)
        node.results["results"][q.name]["threshold"] = float(threshold)
        node.results["results"][q.name]["fidelity"] = float(fidelity)
        node.results["results"][q.name]["confusion_matrix"] = np.array([[gg, ge], [eg, ee]])
        node.results["results"][q.name]["rus_threshold"] = float(RUS_threshold)

    # %% {Plotting}
    grid = QubitGrid(ds, [q.grid_location for q in qubits])
    for ax, qubit in grid_iter(grid):
        n_avg = n_runs // 2
        qn = qubit["qubit"]
        # TODO: maybe wrap it up in a function plot_IQ_blobs?
        ax.plot(
            1e3
            * (
                ds.I_g.sel(qubit=qn) * np.cos(node.results["results"][qn]["angle"])
                - ds.Q_g.sel(qubit=qn) * np.sin(node.results["results"][qn]["angle"])
            ),
            1e3
            * (
                ds.I_g.sel(qubit=qn) * np.sin(node.results["results"][qn]["angle"])
                + ds.Q_g.sel(qubit=qn) * np.cos(node.results["results"][qn]["angle"])
            ),
            ".",
            alpha=0.2,
            label="Ground",
            markersize=1,
        )
        ax.plot(
            1e3
            * (
                ds.I_e.sel(qubit=qn) * np.cos(node.results["results"][qn]["angle"])
                - ds.Q_e.sel(qubit=qn) * np.sin(node.results["results"][qn]["angle"])
            ),
            1e3
            * (
                ds.I_e.sel(qubit=qn) * np.sin(node.results["results"][qn]["angle"])
                + ds.Q_e.sel(qubit=qn) * np.cos(node.results["results"][qn]["angle"])
            ),
            ".",
            alpha=0.2,
            label="Excited",
            markersize=1,
        )
        ax.axvline(
            1e3 * node.results["results"][qn]["rus_threshold"],
            color="k",
            linestyle="--",
            lw=0.5,
            label="RUS Threshold",
        )
        ax.axvline(
            1e3 * node.results["results"][qn]["threshold"],
            color="r",
            linestyle="--",
            lw=0.5,
            label="Threshold",
        )
        ax.axis("equal")
        ax.set_xlabel("I [mV]")
        ax.set_ylabel("Q [mV]")
        ax.set_title(qubit["qubit"])

    ax.legend(loc="center left", bbox_to_anchor=(1, 0.5))
    grid.fig.suptitle("g.s. and e.s. discriminators (rotated)")
    plt.tight_layout()
    node.results["figure_IQ_blobs"] = grid.fig

    grid = QubitGrid(ds, [q.grid_location for q in qubits])
    for ax, qubit in grid_iter(grid):
        confusion = node.results["results"][qubit["qubit"]]["confusion_matrix"]
        ax.imshow(confusion)
        ax.set_xticks([0, 1])
        ax.set_yticks([0, 1])
        ax.set_xticklabels(labels=["|g>", "|e>"])
        ax.set_yticklabels(labels=["|g>", "|e>"])
        ax.set_ylabel("Prepared")
        ax.set_xlabel("Measured")
        ax.text(0, 0, f"{100 * confusion[0][0]:.1f}%", ha="center", va="center", color="k")
        ax.text(1, 0, f"{100 * confusion[0][1]:.1f}%", ha="center", va="center", color="w")
        ax.text(0, 1, f"{100 * confusion[1][0]:.1f}%", ha="center", va="center", color="w")
        ax.text(1, 1, f"{100 * confusion[1][1]:.1f}%", ha="center", va="center", color="k")
        ax.set_title(qubit["qubit"])

    grid.fig.suptitle("g.s. and e.s. fidelity")
    plt.tight_layout()
    plt.show()
    node.results["figure_fidelity"] = grid.fig


    # Plot raw IQ streams (no subplots) and annotate with the computed state for each qubit
    if "figs" not in node.results:
        node.results["figs"] = {}

    for i, q in enumerate(qubits):
        fig, ax = plt.subplots(figsize=(6, 6))
        plotted_any = False

        # Define bases and colors for the IQ pairs
        pairs = [("I_g", "Q_g", "Ground", "C0"), ("I_e", "Q_e", "Excited", "C1"), ("I_f", "Q_f", "|2>", "C2")]

        # Try to find matching I/Q pairs, including suffixed variants (e.g., I_g1 / Q_g1)
        for I_base, Q_base, label_base, color in pairs:
            # find any I keys that start with the I_base
            I_candidates = [k for k in ds.data_vars if k.startswith(I_base)]
            for I_key in I_candidates:
                suffix = I_key[len(I_base) :]  # may be empty or like '1', '2', etc.
                Q_key = Q_base + suffix
                if Q_key not in ds.data_vars:
                    continue
                try:
                    I_series = ds[I_key].sel(qubit=q.name).values
                    Q_series = ds[Q_key].sel(qubit=q.name).values
                except Exception:
                    continue

                shots = np.arange(1, I_series.size + 1)
                ax.plot(
                    1e3 * I_series,
                    1e3 * Q_series,
                    ".",
                    alpha=0.25 if label_base != "|2>" else .95,
                    markersize=1.5,
                    color=color,
                    label=f"{label_base}{suffix}" if suffix else label_base,
                )
                plotted_any = True

        # If nothing plotted, fall back to plotting any I/Q named exactly (no suffix)
        if not plotted_any:
            for I_base, Q_base, label_base, color in pairs:
                if I_base in ds.data_vars and Q_base in ds.data_vars:
                    try:
                        I_series = ds[I_base].sel(qubit=q.name).values
                        Q_series = ds[Q_base].sel(qubit=q.name).values
                        ax.plot(1e3 * I_series, 1e3 * Q_series, ".", alpha=0.25, markersize=1.5, color=color, label=label_base)
                        plotted_any = True
                    except Exception:
                        pass

        ax.set_xlabel("I [mV]")
        ax.set_ylabel("Q [mV]")
        ax.set_title(f"I vs Q — {q.name} - Intermidiate freq. { q.xy.intermediate_frequency/1e6} MHz , {(q.anharmonicity)/1e6} MHz")
        ax.axis("equal")
        ax.grid(False)
        if plotted_any:
            ax.legend(loc="upper right", fontsize="small", markerscale=3)

        # annotate with the computed state if available
        state = node.results.get("results", {}).get(q.name, {})
        angle = state.get("angle", np.nan)
        threshold = state.get("threshold", np.nan)
        rus_threshold = state.get("rus_threshold", np.nan)
        fidelity = state.get("fidelity", np.nan)
        conf = state.get("confusion_matrix", None)

        info_lines = [
            f"angle = {angle:.6f}",
            f"threshold = {threshold:.6f}",
            f"RUS threshold = {rus_threshold:.6f}",
            f"fidelity = {fidelity:.4f}",
        ]
        if conf is not None:
            info_lines.append("confusion:")
            try:
                cm = np.array(conf)
                info_lines += [f"[{cm[0,0]:.3f} {cm[0,1]:.3f}]", f"[{cm[1,0]:.3f} {cm[1,1]:.3f}]"]
            except Exception:
                info_lines.append(str(conf))

        ax.text(
            0.99,
            0.01,
            "\n".join(info_lines),
            ha="right",
            va="bottom",
            transform=ax.transAxes,
            fontsize=8,
            bbox=dict(facecolor="white", alpha=0.8, edgecolor="none"),
        )

        plt.tight_layout()
        node.results["figs"][f"raw_IQ_{q.name}"] = fig
        plt.show()

    # %% {Update_state}
    if node.parameters.load_data_id is None:
        with node.record_state_updates():
            for qubit in qubits:
                qubit.resonator.operations[operation_name].integration_weights_angle -= float(
                    node.results["results"][qubit.name]["angle"]
                )
                # Convert the thresholds back in demod units
                qubit.resonator.operations[operation_name].threshold = (
                    float(node.results["results"][qubit.name]["threshold"])
                    * qubit.resonator.operations[operation_name].length
                    / 2**12
                )
                # todo: add conf matrix to the readout operation rather than the resonator
                qubit.resonator.operations[operation_name].rus_exit_threshold = (
                    float(node.results["results"][qubit.name]["rus_threshold"])
                    * qubit.resonator.operations[operation_name].length
                    / 2**12
                )
                if operation_name == "readout":
                    qubit.resonator.confusion_matrix = node.results["results"][qubit.name]["confusion_matrix"].tolist()

        # %% {Save_results}
        node.outcomes = {q.name: "successful" for q in qubits}
        node.results["initial_parameters"] = node.parameters.model_dump()
        node.machine = machine
        node.save()
